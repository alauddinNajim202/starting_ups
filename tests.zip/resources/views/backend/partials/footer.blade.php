<div class="footer py-4 d-flex flex-lg-column " id="kt_footer">
    <div class=" container-fluid  d-flex flex-column flex-md-row flex-stack">
        <div class="text-dark order-2 order-md-1">
            <span class="text-muted fw-semibold me-2">Copyright || @ 2025</span>
        </div>
    </div>
</div>
